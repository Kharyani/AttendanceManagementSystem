from database import connect_db
from utils import create_csv

from attendance import (
    mark_attendance,
    view_records,
    update_record,
    delete_record
)

from reports import generate_report


# Initialize database and CSV
connect_db()
create_csv()


while True:

    print("\n========== Attendance Management System ==========")

    print("1. Mark Attendance")
    print("2. View Records")
    print("3. Update Record")
    print("4. Delete Record")
    print("5. Generate Report")
    print("6. Exit")

    choice = input("\nEnter your choice: ").strip()

    if choice == "1":
        mark_attendance()

    elif choice == "2":
        view_records()

    elif choice == "3":
        update_record()

    elif choice == "4":
        delete_record()

    elif choice == "5":
        generate_report()

    elif choice == "6":
        print("Exiting program...")
        break

    else:
        print("Invalid choice! Please try again.")