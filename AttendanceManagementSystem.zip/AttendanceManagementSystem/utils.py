import csv
import os

CSV_FILE = "attendance.csv"

def create_csv():
    if not os.path.exists(CSV_FILE):
        with open(CSV_FILE, "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Student ID", "Name", "Date", "Status"])