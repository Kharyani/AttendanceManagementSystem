import sqlite3
import csv

def generate_report():

    sid = input("Enter Student ID: ").strip()

    try:
        conn = sqlite3.connect("attendance.db")
        cursor = conn.cursor()

        cursor.execute("""
        SELECT status FROM attendance
        WHERE LOWER(student_id)=LOWER(?)
        """, (sid,))

        records = cursor.fetchall()

        if len(records) == 0:
            print("No attendance record found!")
            conn.close()
            return

        total = len(records)

        present = sum(1 for r in records if r[0] == "Present")
        absent = sum(1 for r in records if r[0] == "Absent")
        late = sum(1 for r in records if r[0] == "Late")

        percentage = (present / total) * 100

        print("\n===== Attendance Report =====")
        print(f"Total Days   : {total}")
        print(f"Present Days : {present}")
        print(f"Absent Days  : {absent}")
        print(f"Late Days    : {late}")
        print(f"Percentage   : {percentage:.2f}%")

        # Export report to CSV
        with open("report.csv", "w", newline="") as file:

            writer = csv.writer(file)

            writer.writerow([
                "Student ID",
                "Total Days",
                "Present",
                "Absent",
                "Late",
                "Percentage"
            ])

            writer.writerow([
                sid,
                total,
                present,
                absent,
                late,
                f"{percentage:.2f}%"
            ])

        print("\nReport exported to report.csv")

        conn.close()

    except Exception as e:
        print("Error:", e)