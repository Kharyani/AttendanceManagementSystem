import sqlite3
import csv

CSV_FILE = "attendance.csv"


# =========================
# MARK ATTENDANCE
# =========================
def mark_attendance():

    student_id = input("Enter Student ID: ").strip()
    name = input("Enter Name: ").strip()
    date = input("Enter Date (YYYY-MM-DD): ").strip()
    status = input("Enter Status (Present/Absent/Late): ").capitalize().strip()

    # Input Validation
    if not student_id or not name or not date:
        print("Fields cannot be empty!")
        return

    if status not in ["Present", "Absent", "Late"]:
        print("Invalid Status!")
        return

    try:
        conn = sqlite3.connect("attendance.db")
        cursor = conn.cursor()

        # Check duplicate attendance
        cursor.execute("""
        SELECT * FROM attendance
        WHERE LOWER(student_id)=LOWER(?)
        AND date=?
        """, (student_id, date))

        existing_record = cursor.fetchone()

        if existing_record:
            print("Attendance already marked for this date!")
            conn.close()
            return

        # Insert into database
        cursor.execute("""
        INSERT INTO attendance(student_id, name, date, status)
        VALUES (?, ?, ?, ?)
        """, (student_id, name, date, status))

        conn.commit()

        # Insert into CSV
        with open(CSV_FILE, "a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([student_id, name, date, status])

        print("Attendance marked successfully!")

        conn.close()

    except Exception as e:
        print("Error:", e)


# =========================
# VIEW RECORDS
# =========================
def view_records():

    choice = input("Search by Date or ID? ").lower().strip()

    try:
        conn = sqlite3.connect("attendance.db")
        cursor = conn.cursor()

        if choice == "date":

            date = input("Enter Date (YYYY-MM-DD): ")

            cursor.execute("""
            SELECT * FROM attendance
            WHERE date=?
            """, (date,))

        elif choice == "id":

            sid = input("Enter Student ID: ")

            cursor.execute("""
            SELECT * FROM attendance
            WHERE LOWER(student_id)=LOWER(?)
            """, (sid,))

        else:
            print("Invalid choice!")
            conn.close()
            return

        records = cursor.fetchall()

        if len(records) == 0:
            print("No records found!")

        else:
            print("\n===== Attendance Records =====")

            for row in records:
                print(f"""
Record ID : {row[0]}
Student ID: {row[1]}
Name      : {row[2]}
Date      : {row[3]}
Status    : {row[4]}
-----------------------------
""")

        conn.close()

    except Exception as e:
        print("Error:", e)


# =========================
# UPDATE RECORD
# =========================
def update_record():

    sid = input("Enter Student ID: ").strip()
    date = input("Enter Date (YYYY-MM-DD): ").strip()

    try:
        conn = sqlite3.connect("attendance.db")
        cursor = conn.cursor()

        # Check if record exists
        cursor.execute("""
        SELECT * FROM attendance
        WHERE LOWER(student_id)=LOWER(?)
        AND date=?
        """, (sid, date))

        record = cursor.fetchone()

        if not record:
            print("Record not found!")
            conn.close()
            return

        new_status = input("Enter New Status (Present/Absent/Late): ").capitalize().strip()

        if new_status not in ["Present", "Absent", "Late"]:
            print("Invalid Status!")
            conn.close()
            return

        # Update database
        cursor.execute("""
        UPDATE attendance
        SET status=?
        WHERE LOWER(student_id)=LOWER(?)
        AND date=?
        """, (new_status, sid, date))

        conn.commit()

        print("Record updated successfully!")

        conn.close()

    except Exception as e:
        print("Error:", e)


# =========================
# DELETE RECORD
# =========================
def delete_record():

    sid = input("Enter Student ID: ").strip()
    date = input("Enter Date (YYYY-MM-DD): ").strip()

    try:
        conn = sqlite3.connect("attendance.db")
        cursor = conn.cursor()

        # Check if record exists
        cursor.execute("""
        SELECT * FROM attendance
        WHERE LOWER(student_id)=LOWER(?)
        AND date=?
        """, (sid, date))

        record = cursor.fetchone()

        if not record:
            print("Record not found!")
            conn.close()
            return

        # Delete record
        cursor.execute("""
        DELETE FROM attendance
        WHERE LOWER(student_id)=LOWER(?)
        AND date=?
        """, (sid, date))

        conn.commit()

        print("Record deleted successfully!")

        conn.close()

    except Exception as e:
        print("Error:", e)